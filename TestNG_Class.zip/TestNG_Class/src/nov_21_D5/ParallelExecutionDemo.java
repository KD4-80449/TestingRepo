package nov_21_D5;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;

public class ParallelExecutionDemo {

	
	@Test(priority = 1)
  public void OpenChrome() {
	 WebDriver wd = new ChromeDriver();	
	wd.get("https://www.gmail.com");
	
  }
	
	@Test(priority = 2)
	  public void OpenFirefox() {
		 WebDriver wd = new FirefoxDriver();	
		 wd.get("https://www.homecanvas.com");
	  }
 
	
}
