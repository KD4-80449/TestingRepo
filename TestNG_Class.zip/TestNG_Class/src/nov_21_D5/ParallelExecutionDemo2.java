package nov_21_D5;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class ParallelExecutionDemo2 {
  @Test(groups = "Sanity")
  public void SwagLab() throws InterruptedException {
	  WebDriver wd = new ChromeDriver();
	  wd.get("https://www.saucedemo.com/");
	  wd.findElement(By.id("user-name")).sendKeys("visual_user");
	  wd.findElement(By.id("password")).sendKeys("secret_sauce");
	  Thread.sleep(2000);
	  wd.findElement(By.id("login-button")).click();
	  Thread.sleep(2000);
	  wd.close();
	  
	  System.out.println("TestCase in sanity group");
  }
  
  @Test
  public void TestLogin() throws InterruptedException {
	  WebDriver wd = new ChromeDriver();
	  wd.get("https://practicetestautomation.com/practice-test-login/"); 
	  wd.findElement(By.id("username")).sendKeys("student");
	  wd.findElement(By.id("password")).sendKeys("Password123");
	  Thread.sleep(2000);
	  wd.findElement(By.id("submit")).click();
	  Thread.sleep(2000);
	  wd.close();
  }
}
