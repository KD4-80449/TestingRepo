package nov_19_D3;

import org.testng.annotations.Test;

public class RunningMultiplecases {
  @Test
  public void f() {
  }
}
