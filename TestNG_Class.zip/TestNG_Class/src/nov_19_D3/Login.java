package nov_19_D3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Login {
	@Parameters({"userName","Password"})
	@Test
  public void weblogin(String userName , String Password) throws InterruptedException {
	  WebDriver wd = new ChromeDriver();
	  wd.get("https://automationexercise.com/login");
	  Thread.sleep(2000);
	  wd.manage().window().maximize();
	  wd.findElement(By.xpath("//input[@data-qa='login-email']")).sendKeys(userName);
	  Thread.sleep(3000);
	  wd.findElement(By.xpath("//input[@data-qa='login-password']")).sendKeys(Password);
	  Thread.sleep(3000);
	  wd.findElement(By.xpath("//button[@data-qa='login-button']")).click();
	  
	  Thread.sleep(3000);
	  wd.close();
			  
	  
  }
}
