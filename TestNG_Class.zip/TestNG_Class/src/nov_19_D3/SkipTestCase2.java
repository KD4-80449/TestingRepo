package nov_19_D3;

import org.testng.SkipException;
import org.testng.annotations.Test;

public class SkipTestCase2 {
 
  @Test (priority = 4) // 
  public void Profile() {
	  throw new SkipException("Available sooner.."); // should always be 1st line and should not have any line of code afterwords
	 // System.out.println("Profile");
  }
 
  @Test(priority = 2)
  public void login() throws InterruptedException {
	System.out.println("Login Testcase");
	  
  }
  
  @Test(priority = 3)
  public void logOut() throws InterruptedException {
	  System.out.println("Log out Testcase");
	  
  }
  
  @Test(priority = 1)
  public void register() throws InterruptedException {
	  System.out.println("Register Testcase");
	  
  }
  
  @Test(priority = 5)
  public void dashboard() throws InterruptedException {
	  System.out.println("dashboard Testcase");
	  
  }
}
