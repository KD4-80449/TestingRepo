package nov_19_D3;

import org.testng.annotations.Test;

public class LoginParameterised {
  @Test
  public void f() {
  }
}
