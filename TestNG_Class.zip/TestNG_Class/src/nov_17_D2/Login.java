package nov_17_D2;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class Login {
	WebDriver wd = new ChromeDriver();
	
  @Test
  public void loginMethod() throws InterruptedException {
	  wd.findElement(By.id("username")).sendKeys("practice");
	  Thread.sleep(2000);
	  wd.findElement(By.id("password")).sendKeys("SuperSecretPassword!");
	  Thread.sleep(2000);
	  wd.findElement(By.id("submit-login")).click();
	 
	  
  }
  
  
  @BeforeTest
  public void beforeTest() throws InterruptedException {
	  wd.get("https://practice.expandtesting.com/login#google_vignette");
	  wd.manage().window().maximize();
	  Thread.sleep(6000);
	 // wd.close();
	  
  }

  @AfterTest
  public void afterTest() {
	  wd.close();
  }

}
