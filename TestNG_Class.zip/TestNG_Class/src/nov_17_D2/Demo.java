package nov_17_D2;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;


public class Demo {
	
   WebDriver wd = new ChromeDriver();
  @Test
  public void login() throws InterruptedException {
	  wd.findElement(By.id("username")).sendKeys("student");;
	  wd.findElement(By.id("password")).sendKeys("Password123");
	  Thread.sleep(4000);
	  wd.findElement(By.id("submit")).click();
	  
	 
	  
	  
  }
  
  @BeforeTest
  public void beforeTest() throws InterruptedException {
	  System.out.println("Before");
	 
	  wd.get("https://practicetestautomation.com/practice-test-login/");
	  wd.manage().window().maximize();
	  Thread.sleep(4000);
	  wd.close();
  }

  @AfterTest
  public void afterTest() {
  }

}
