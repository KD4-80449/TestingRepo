package nov_17_D2;

import org.testng.annotations.Test;

public class priority {

  @Test(priority = 1)
  public void login() throws InterruptedException {
	System.out.println("Login Testcase");
	  
  }
  
  @Test
  public void logOut() throws InterruptedException {
	  System.out.println("Log out Testcase");
	  
  }
  
  @Test(priority = 'm')
  public void register() throws InterruptedException {
	  System.out.println("Register Testcase");
	  
  }
  
  @Test
  public void home() throws InterruptedException {
	  System.out.println("Home Testcase");
	  
  }
}
