package nov_17_D2;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Login_Logout_Priority {
	
  WebDriver wd = new ChromeDriver();
  
  @Test(priority = 2)
  public void login() throws InterruptedException {
	System.out.println("Login Testcase");
	  
  }
  
  @Test(priority = 4)
  public void logOut() throws InterruptedException {
	  System.out.println("Log out Testcase");
	  
  }
  
  @Test(priority = 1)
  public void register() throws InterruptedException {
	  System.out.println("Register Testcase");
	  
  }
  
  @Test(priority = 3)
  public void home() throws InterruptedException {
	  System.out.println("Home Testcase");
	  
  }
  
  
}
