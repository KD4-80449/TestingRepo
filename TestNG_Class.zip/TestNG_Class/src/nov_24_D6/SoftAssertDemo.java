package nov_24_D6;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class SoftAssertDemo {
  @Test
  public void myntra() throws InterruptedException {
	  WebDriver wd = new ChromeDriver();
	  wd.get("https://www.myntra.com");
	  wd.manage().window().maximize();
	
	  String a = wd.getTitle();
	  System.out.println("Title: "+a);
	  String b = "Online Myntra";
	
	  
	  SoftAssert m = new SoftAssert();
	  m.assertEquals(a, b);
	  System.out.println("soft assert executed..");
	 
	  
	  Thread.sleep(1000);
	  wd.close();
	  m.assertAll(); // doesn't execute next line
  }
}
