package nov_24_D6;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class AssersionDemo {
  @Test
  public void GoogleOpen() throws InterruptedException {
	  WebDriver wd = new ChromeDriver();
	  wd.get("https://www.google.com");
	  wd.manage().window().maximize();
	  String a = wd.getTitle();
	  System.out.println("Title : "+wd.getTitle());
	  String m = "Google"; 
	 // String m2 = "gmail";		// m= gmail , google 
	  Assert.assertEquals(a, m); // gmail compares with google (hardAssert)
	  
	  Thread.sleep(3000);
	  wd.close();
	  
  }
}
