package nov_24_D6;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class HardAssertDemo_positive {
  @Test
  public void flipkart() throws InterruptedException {
	  WebDriver wd = new ChromeDriver();
	  wd.get("https://www.flipkart.com");
	  wd.manage().window().maximize();
	  String a = wd.getTitle();
	  System.out.println("title : "+a);
	  String b = "Online Shopping India Mobile, Cameras, Lifestyle & more Online @ Flipkart.com";
	  Assert.assertEquals(a, b);
	  System.out.println("aaertion completed ..");
	  Thread.sleep(3000);
	  wd.close();
  }
}
