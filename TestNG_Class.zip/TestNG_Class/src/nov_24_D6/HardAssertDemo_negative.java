package nov_24_D6;

import org.testng.annotations.Test;

public class HardAssertDemo_negative {
  @Test
  public void f() {
  }
}
