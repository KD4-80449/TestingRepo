package nov_26_D7;

import org.testng.annotations.Test;

public class KeywordDrivenFrameworkDemo2 {
  @Test
  public void f() {
	  
  }
}
