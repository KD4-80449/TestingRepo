package nov_26_D7;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Keyword_drivenframework {
  @Test
  public void SwagLabLogin() throws IOException {
	  WebDriver wd = new ChromeDriver();
	  Properties pr = new Properties();
	  FileReader fr = new FileReader("D:\\Testing\\AutomationTesting\\TestNgPractical\\TestNG_Class\\src\\nov_26_D7\\SwagLabInput.properties");
	  pr.load(fr);
	  wd.get(pr.getProperty("Url"));
	  
	  wd.findElement(By.id("user-name")).sendKeys(pr.getProperty("UserName"));
	  wd.findElement(By.id("password")).sendKeys(pr.getProperty("Password"));
	  wd.findElement(By.id("login-button")).click();
	  
  }
}
