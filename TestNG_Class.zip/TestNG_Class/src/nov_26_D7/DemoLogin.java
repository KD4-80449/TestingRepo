package nov_26_D7;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class DemoLogin {
  @Test
  public void f() throws InterruptedException, IOException {
	  WebDriver wd = new ChromeDriver();
	  wd.get("https://practicetestautomation.com/practice-test-login/");
	  wd.manage().window().maximize();
	  Properties pr = new Properties();
	  //pr.load("D:\\Testing\\AutomationTesting\\TestNgPractical\\TestNG_Class\\src\\nov_26_D7\\InputData.properties");
	  FileReader fr = new FileReader("D:\\Testing\\AutomationTesting\\TestNgPractical\\TestNG_Class\\src\\nov_26_D7\\InputData.properties");
	  pr.load(fr);
	  wd.findElement(By.id("username")).sendKeys(pr.getProperty("UserName"));
	  wd.findElement(By.id("password")).sendKeys(pr.getProperty("Password"));
	  wd.findElement(By.id("submit")).click();
	  
	  
	  Thread.sleep(5000);
	  wd.close();
  }
}
