package nov_20_D4;

import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;

public class DemoDataProvider {
  @Test(dataProvider = "dp")
  
  public void f(String UserName, String Password) throws InterruptedException {
	  WebDriver wd = new ChromeDriver();
	  wd.get("http://testphp.vulnweb.com/login.php");
	  Thread.sleep(2000);
	  wd.findElement(By.xpath("//input[@name='uname']")).sendKeys(UserName);
	  Thread.sleep(2000);
	  wd.findElement(By.xpath("//input[@name='pass']")).sendKeys(Password);
	  Thread.sleep(2000);
	  wd.findElement(By.xpath("//input[@value='login']")).click();
	  Thread.sleep(2000);
	  
	  
	  Thread.sleep(4000);
	  wd.close();
  }

  @DataProvider
  public Object[][] dp() {
    return new Object[][] {
      new Object[] { "Mayuri", "Md123" },
      new Object[] { "Naina", "N123" },
    };
  }
}
