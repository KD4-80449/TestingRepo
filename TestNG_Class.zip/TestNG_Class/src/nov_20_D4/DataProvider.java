package nov_20_D4;

import org.testng.annotations.Test;

public class DataProvider {
  @Test
  public void f() {
  }
}
