package nov_20_D4;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class CrossBrowserDemo {
  
	@Parameters({"Browser"})
	 
	
	@Test
  public void BrowserOpen(String Browser) {
	  
	  if(Browser.equalsIgnoreCase("Chrome")) {
		  WebDriver wd = new ChromeDriver();
		  wd.get("https://www.google.com");
		  
	  }else if(Browser.equalsIgnoreCase("Firefox")) {
		  WebDriver wd = new FirefoxDriver(); 
		  wd.get("https://www.filpcart.com");
		  
	  }else if(Browser.equalsIgnoreCase("Edge")) {
		  WebDriver wd = new EdgeDriver(); 
		  wd.get("https://www.gmail.com");
		  
	  }else {
		  System.out.println("Invalid input Try again..");
	  }
	  
  }
}
